package pl.jakub.ultraopt.performance;

public enum PerformanceProfile {
    LOW,
    MEDIUM,
    HIGH,
    ULTRA
}