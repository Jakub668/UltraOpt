package pl.jakub.ultraopt.edit;

public class UltraEdit {

    public static final Selection SELECTION = new Selection();
    public static final Clipboard CLIPBOARD = new Clipboard();
}