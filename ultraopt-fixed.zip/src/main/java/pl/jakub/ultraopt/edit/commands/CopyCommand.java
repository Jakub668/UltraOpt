package pl.jakub.ultraopt.edit.commands;

import pl.jakub.ultraopt.edit.UltraEdit;

public class CopyCommand {

    public static void execute() {
        // TODO: kopiowanie bloków do Clipboard
        UltraEdit.CLIPBOARD.toString();
    }
}