package pl.jakub.ultraopt.edit;

public class Clipboard {
    // na razie pusty – wkleimy strukturę później
}