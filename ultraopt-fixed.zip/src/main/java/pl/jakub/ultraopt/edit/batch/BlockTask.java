package pl.jakub.ultraopt.edit.batch;

public record BlockTask(int x, int y, int z) {}