package pl.jakub.ultraopt.edit.commands;

public class SetCommand {
    // TODO: batch set blocks
}