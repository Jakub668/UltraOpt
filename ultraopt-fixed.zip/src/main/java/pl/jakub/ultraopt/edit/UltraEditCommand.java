package pl.jakub.ultraopt.edit;

public class UltraEditCommand {
    // rejestracja sub-komend (pos1, pos2, copy, paste)
}