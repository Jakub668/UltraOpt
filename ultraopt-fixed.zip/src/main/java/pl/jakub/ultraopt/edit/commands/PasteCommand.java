package pl.jakub.ultraopt.edit.commands;

public class PasteCommand {

    public static void execute() {
        // TODO: batch paste z Clipboard
    }
}