package pl.jakub.ultraopt.edit.batch;

public class BatchExecutor {

    public static void tick() {
        // w przyszłości limit bloków / tick
    }
}