package pl.jakub.ultraopt.edit.commands;

public class Pos1Command {
}